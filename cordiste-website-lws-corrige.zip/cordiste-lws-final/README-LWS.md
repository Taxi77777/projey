# Guide de déploiement sur LWS

## Problèmes identifiés et solutions

### 1. Erreur 403 - Causes possibles :
- **Permissions de fichiers incorrectes** ✅ CORRIGÉ
- **Configuration .htaccess trop restrictive** ✅ CORRIGÉ  
- **Fichiers cachés bloqués** ✅ CORRIGÉ

### 2. Solutions appliquées :

#### Permissions corrigées :
- Dossiers : 755 (lecture/exécution pour tous)
- Fichiers : 644 (lecture pour tous, écriture pour propriétaire)

#### Configuration .htaccess simplifiée :
- Suppression des règles de sécurité trop restrictives
- Conservation du routing React essentiel
- Optimisations de cache et compression maintenues

### 3. Instructions de déploiement sur LWS :

1. **Télécharger tous les fichiers** dans le dossier racine de votre hébergement LWS
2. **Vérifier que le fichier .htaccess** est bien présent (parfois masqué)
3. **Attendre 5-10 minutes** pour la propagation des changements
4. **Tester l'accès** à votre site

### 4. Structure des fichiers :
```
/
├── index.html (point d'entrée)
├── .htaccess (configuration Apache)
├── assets/ (ressources CSS, JS, images)
├── 404.html (page d'erreur)
├── robots.txt
├── sitemap.xml
└── favicon.ico
```

### 5. Vérifications post-déploiement :
- [ ] Le site s'affiche correctement
- [ ] La navigation fonctionne (pas d'erreur 404)
- [ ] Les images se chargent
- [ ] Les styles CSS s'appliquent

### 6. En cas de problème persistant :
- Vérifier les logs d'erreur dans l'interface LWS
- Contacter le support LWS si nécessaire
- S'assurer que le module mod_rewrite est activé

